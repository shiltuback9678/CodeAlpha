from scapy.all import sniff, IP, TCP, UDP, ICMP, wrpcap

# List to store captured packets
captured_packets = []

def packet_callback(packet):
    if IP in packet:
        captured_packets.append(packet)
        ip_src = packet[IP].src
        ip_dst = packet[IP].dst
        protocol = packet[IP].proto
        
        if protocol == 6 and TCP in packet:  # TCP protocol
            tcp_sport = packet[TCP].sport
            tcp_dport = packet[TCP].dport
            print(f"TCP Packet: {ip_src}:{tcp_sport} -> {ip_dst}:{tcp_dport}")
        
        elif protocol == 17 and UDP in packet:  # UDP protocol
            udp_sport = packet[UDP].sport
            udp_dport = packet[UDP].dport
            print(f"UDP Packet: {ip_src}:{udp_sport} -> {ip_dst}:{udp_dport}")
        
        elif protocol == 1:  # ICMP protocol
            print(f"ICMP Packet: {ip_src} -> {ip_dst}")
        
        else:
            print(f"Other IP Packet: {ip_src} -> {ip_dst} (Protocol: {protocol})")
    else:
        print("Non-IP packet detected")

# Start sniffing
sniff(prn=packet_callback, count=50)  # Increase count for more packets

# Save the captured packets to a file
wrpcap('captured_packets.pcap', captured_packets)

